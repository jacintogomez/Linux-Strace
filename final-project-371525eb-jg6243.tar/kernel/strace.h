#define straceOn 1
#define straceFork 2
#define straceOff 0